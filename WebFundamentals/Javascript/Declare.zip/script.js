$(document).ready(function()
{
  declare();
});

function declare(){
  console.log('In declare.');
  var num1 = 1;
  var num2 = 2;
  var num3 = 3;
  var num4 = 4;
  console.log("num1= "+num1);
  console.log("num2= "+num2);
  console.log("num3= "+num3);
  console.log("num4= "+num4);
  var string1="String1";
  var string2="String2";
  var string3="String3";
  var string4="String4";
  console.log("String1="+string1);
  console.log("String2="+string2);
  console.log("String3="+string3);
  console.log("String4="+string4);
  var bol1=true;
  var bol2=true;
  var bol3=true;
  console.log("bol1="+bol1);
  console.log("bol2="+bol2);
  console.log("bol3="+bol3);
  var unknown;
  console.log("unknown="+unknown);
  console.log('Out declare.');
}
