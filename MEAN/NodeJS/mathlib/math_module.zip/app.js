var math = require('./mathlib');
var result = math.add(2,3)
console.log( result + '/n' );
result = math.multiply(100,100);
console.log( result + '/n' );
result = math.square(88);
console.log( result + '/n' );
result = math.random( 6, 10 );
console.log( result + '/n' );
